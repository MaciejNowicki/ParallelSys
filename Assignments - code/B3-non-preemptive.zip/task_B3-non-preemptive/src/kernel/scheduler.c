/*!
 * \file scheduler.c
 * \brief
 *  This file holds the scheduler code. 
 */

#include "kernel.h"

void
scheduler_called_from_system_call_handler(const register int schedule)
{
	int running_thread_index;

	if( schedule == 1 )
	{
//		kprints("SCHEDULER_SYSTEM_CALL\nready table\n");
//		kprinthex(thread_queue_head(&ready_queue));
//		kprints("\n");
//		kprinthex(thread_queue_tail(&ready_queue));
//		kprints("\nrunning thread\n");
//		kprinthex(cpu_private_data.thread_index);
//		kprints("\nnew thread\n");

		running_thread_index = cpu_private_data.thread_index;
		if( (-1) != thread_table[running_thread_index].data.owner )
		{
			thread_queue_enqueue( &ready_queue , running_thread_index );
		}
		cpu_private_data.thread_index = thread_queue_dequeue( &ready_queue );

//		kprinthex(cpu_private_data.thread_index);
//		kprints("\n");
	}
}

void
scheduler_called_from_timer_interrupt_handler(const register int thread_changed)
{
}
