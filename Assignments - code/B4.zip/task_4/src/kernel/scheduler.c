/*!
 * \file scheduler.c
 * \brief
 *  This file holds the scheduler code. 
 */

#include "kernel.h"

void
scheduler_called_from_system_call_handler(const register int schedule)
{
	int running_thread_index;

	if( schedule == 1 )
	{
		running_thread_index = cpu_private_data.thread_index;
		if( (-1) != thread_table[running_thread_index].data.owner &&
				thread_table[running_thread_index].data.list_data == 0 )
		{
			thread_queue_enqueue( &ready_queue , running_thread_index );
		}
		cpu_private_data.thread_index = thread_queue_dequeue( &ready_queue );

//		kprints("!!SWITCHED THREAD!!\n");
//		int tmp_thr=thread_queue_head(&ready_queue);
//		kprints("\nRUNNING THREAD: ");
//		kprinthex(cpu_private_data.thread_index);
//		kprints("\nREADY LIST:\n");
//		while( tmp_thr != (-1) )
//		{
//			kprints("   ");
//			kprinthex( tmp_thr );
//			kprints("\n");
//			tmp_thr = thread_table[tmp_thr].data.next;
//		}
//		kprints("TICKS LEFT OF TIME SLICE\n");
//		kprinthex(cpu_private_data.ticks_left_of_time_slice);
//		kprints("\n\n");
	}
}

void
scheduler_called_from_timer_interrupt_handler(const register int thread_changed)
{
	int running_thread_index;

	if( thread_changed == 1 )
	{
		cpu_private_data.ticks_left_of_time_slice = 5;
	}

	if( thread_changed == 0  &&  cpu_private_data.ticks_left_of_time_slice == 0 )
	{
		cpu_private_data.ticks_left_of_time_slice = 5;

		running_thread_index = cpu_private_data.thread_index;
		thread_queue_enqueue( &ready_queue , running_thread_index );
		cpu_private_data.thread_index = thread_queue_dequeue( &ready_queue );

	}

	if( cpu_private_data.ticks_left_of_time_slice>0 )
		cpu_private_data.ticks_left_of_time_slice--;
}
