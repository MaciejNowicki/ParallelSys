/*! \file 
    \brief Holds the implementation of the memory sub-system. */

#include "kernel.h"
#include "mm.h"

/* Variable definitions. */

struct page_frame
page_frame_table[MAX_NUMBER_OF_FRAMES];

/* Set when the system is initialized. */
unsigned long memory_pages;

/* The following three variables are set by the assembly code. */
unsigned long first_available_memory_byte;

unsigned long memory_size;

unsigned long kernel_page_table_root;

/* Function definitions. */

/* Change this function in task B4. */
long
kalloc(const register unsigned long length,
       const register unsigned int  process,
       const register unsigned long flags)
{
	int i , memory_page_index = (-1) , first_available_memory_page;
	long memory_adress;
	unsigned long number_of_memory_pages_to_be_used , free_memory_pages_in_sequence=0;

	/* Calculates the number of memory pages to be allocated */
	number_of_memory_pages_to_be_used = ((length+4095)>>12);

	/* Calculates the index of first free memory page */
	first_available_memory_page = first_available_memory_byte>>12;

	/* Loop which searches for available contiguous pages */
	i = first_available_memory_byte>>12;
	while( i<memory_pages )
	{
		/* Checks if page is free */
		if( page_frame_table[i].owner == (-1) )
		{
			free_memory_pages_in_sequence++;
		}
		else
		{
			free_memory_pages_in_sequence = 0;
		}

		/* Checks if number of contiguous free pages is enough for allocation */
		if( number_of_memory_pages_to_be_used == free_memory_pages_in_sequence )
		{
			/* Sets the index to the start of the block */
			memory_page_index = i-number_of_memory_pages_to_be_used+1;

			/* if the start of the block is the first free page,
			 *  updates the first free page index */
			if( memory_page_index == first_available_memory_page )
			{
				first_available_memory_page += number_of_memory_pages_to_be_used;
				first_available_memory_byte = first_available_memory_page<<12;
			}

			break;
		}

		i++;
	}

	/* Sets proper options for the memory block */
	if( memory_page_index != (-1) )
	{
		for( i=0 ; i<number_of_memory_pages_to_be_used ; i++ )
		{
			page_frame_table[i+memory_page_index].owner = process;
			page_frame_table[i+memory_page_index].start = memory_page_index;
			page_frame_table[i+memory_page_index].free_is_allowed = !(flags & ALLOCATE_FLAG_KERNEL);
		}

//		kprints("Memory allocated:\nPage index: ");
//		kprinthex(memory_page_index);
//		kprints("\nNumber of pages: ");
//		kprinthex(number_of_memory_pages_to_be_used);
//		kprints("\n");

		return memory_page_index<<12;
	}

	kprints("Not enough memory! Cannot allocate!\n");
	return ERROR;
}

/* Change this function in task B4. */
long
kfree(const register unsigned long address)
{
	int i , memory_page_start , memory_page_end , first_available_memory_page;

	memory_page_start = address>>12;

	if( page_frame_table[memory_page_start].owner == (-1) )
	{
		kprints("Cannot free memory - memory is not allocated\n");
		return ERROR;
	}

	memory_page_end = memory_page_start;

	while( page_frame_table[memory_page_end].start == memory_page_start )
	{
		memory_page_end++;
	}

	for( i=memory_page_start ; i<memory_page_end ; i++ )
	{
		if( page_frame_table[i].owner != thread_table[cpu_private_data.thread_index].data.owner )
		{
			kprints("Cannot free memory - current process is not the owner of the memory\n");
			return ERROR;
		}
		if( page_frame_table[i].free_is_allowed != 1 )
		{
			kprints("Cannot free memory - memory is not de-allocable\n");
			return ERROR;
		}
	}

	for( i=memory_page_start ; i<memory_page_end ; i++ )
	{
		page_frame_table[i].owner = (-1);
		page_frame_table[i].start = 0;
	}

	first_available_memory_page = first_available_memory_byte>>12;
	if( memory_page_start < first_available_memory_page )
	{
		first_available_memory_byte = memory_page_start<<12;
	}

//	kprints("Memory freed:\nPage index: ");
//	kprinthex(memory_page_start);
//	kprints("\nNumber of pages: ");
//	kprinthex(memory_page_end-memory_page_start);
//	kprints("\n");

	return ALL_OK;
}

/* Change this function in task A4. */
void
update_memory_protection(const register unsigned long page_table,
                         const register unsigned long start_address,
                         const register unsigned long length,
                         const register unsigned long flags)
{
	return;
}

/* Change this function in task A4. */
void
initialize_memory_protection()
{
	return;
}

/* Put any code you need to add to implement tasks B4 and A4 here. */
