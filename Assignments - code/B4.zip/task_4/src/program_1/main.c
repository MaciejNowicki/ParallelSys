/*! \file
 *      \brief The second user program - empty program
 *
 */

#include <scwrapper.h>

int
main(int argc, char* argv[])
{
 return 0;
}
