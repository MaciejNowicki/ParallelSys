/*! \file syscall.c 

 This files holds the implementations of all system calls.

 */

#include "kernel.h"

int
system_call_implementation(void)
{
 switch(SYSCALL_ARGUMENTS.rax)
 {
  case SYSCALL_PRINTS:
  {
   kprints((char*) (SYSCALL_ARGUMENTS.rdi));
   SYSCALL_ARGUMENTS.rax = ALL_OK;
   break;
  }

  case SYSCALL_PRINTHEX:
  {
   kprinthex(SYSCALL_ARGUMENTS.rdi);
   SYSCALL_ARGUMENTS.rax = ALL_OK;
   break;
  }

  case SYSCALL_DEBUGGER:
  {
   /* Enable the bochs iodevice and force a return to the debugger. */
   outw(0x8a00, 0x8a00);
   outw(0x8a00, 0x8ae0);

   SYSCALL_ARGUMENTS.rax = ALL_OK;
   break;
  }

  /* Do not touch any lines above or including this line. */

  /* Add the implementation of more system calls here. */

  case SYSCALL_VERSION:
  {
	  kprinthex( KERNEL_VERSION );

	  SYSCALL_ARGUMENTS.rax = ALL_OK;
	  break;
  }

  case SYSCALL_CREATEPROCESS:
  {
	  int i, free_entry_process=(-1), free_thread=(-1);
	  struct prepare_process_return_value prepare_process_ret_val;

	  SYSCALL_ARGUMENTS.rax = ALL_OK;

	  /* Finds first free entry in the process table */
	  for( i=0 ; i<MAX_NUMBER_OF_PROCESSES ; i++ )
	  {
		  if( process_table[i].threads == 0 )
		  {
			  free_entry_process = i;
			  break;
		  }
	  }

	  /* No free entries in process table */
	  if( (-1) == free_entry_process )
	  {
		  SYSCALL_ARGUMENTS.rax = ERROR;
		  kprints( "Kernel panic! No free entries in the process table!\n" );
		  while( 1 ){}
	  }


	  /* Prepares process, loads the program into the memory */
	  prepare_process_ret_val = prepare_process(
			  executable_table[SYSCALL_ARGUMENTS.rdi].elf_image,
			  free_entry_process,
			  executable_table[SYSCALL_ARGUMENTS.rdi].memory_footprint_size );

	  /* Could not load the program */
	  if ( 0 == prepare_process_ret_val.first_instruction_address )
	  {
		  SYSCALL_ARGUMENTS.rax = ERROR;
		  kprints( "Kernel panic! Cannot start process!\n" );
		  while( 1 ){}
	  }

	  /* Sets the parent for the created process */
	  process_table[free_entry_process].parent = thread_table[current_thread].data.owner;

	  /* Process will have on thread */
	  process_table[free_entry_process].threads = 1;

	  /* Allocates the new thread */
	  free_thread = allocate_thread();

	  /* No threads available */
	  if( free_thread == (-1) )
	  {
		  kprints( "Kernel panic! No thread available!\n" );
		  while( 1 ){}
	  }

	  /* Adds the created thread to to process, and sets the  flags */
	  thread_table[free_thread].data.owner = free_entry_process;
	  thread_table[free_thread].data.registers.integer_registers.rflags = 0;
	  thread_table[free_thread].data.registers.integer_registers.rip = prepare_process_ret_val.first_instruction_address;

	  /* Switches to the new thread */
	  current_thread = free_thread;

	  break;
  }

  case SYSCALL_TERMINATE:
  {
	  int i, this_process, this_thread, this_process_parent;

	  SYSCALL_ARGUMENTS.rax = ALL_OK;

	  /* Gathers info about current process and thread */
	  this_thread = current_thread;
	  this_process = thread_table[this_thread].data.owner;
	  this_process_parent = process_table[this_process].parent;

	  /* Current process has no parent */
	  if( this_process_parent == (-1) )
	  {
		  SYSCALL_ARGUMENTS.rax = ERROR;
		  kprints( "Kernel Panic! No parent process!\n" );
		  while( 1 ){}
	  }

	  /* Removes the thread from the process */
	  thread_table[this_thread].data.owner = (-1);
	  process_table[this_process].threads--;

	  /* Process has no other threads */
	  if( process_table[this_process].threads == 0 )
	  {
		  /* Cleans the process */
		  cleanup_process( this_process );
		  process_table[this_process].parent = (-1);

		  /* Finds new thread from the parent process */
		  for( i=0 ; i<MAX_NUMBER_OF_THREADS ; i++ )
		  {
			  if( thread_table[i].data.owner == this_process_parent )
			  {
				  current_thread = i;
				  break;
			  }
		  }
	  }
	  /* There are some other threads of this process */
	  else
	  {
		  /* Finds other thread from this process */
		  for( i=0 ; i<MAX_NUMBER_OF_THREADS ; i++ )
		  {
			  if( thread_table[i].data.owner == this_process )
			  {
				  current_thread = i;
				  break;
			  }
		  }
	  }

	  /* No other threads found */
	  if( MAX_NUMBER_OF_THREADS == i )
	  {
		  SYSCALL_ARGUMENTS.rax = ERROR;
		  kprints( "Kernel panic! No threads to run\n" );
		  while( 1 ){}
	  }

	  break;
  }


  /* Do not touch any lines below or including this line. */
  default:
  {
   /* No system call defined. */
   SYSCALL_ARGUMENTS.rax = ERROR_ILLEGAL_SYSCALL;
  }
 }

 return 0;
}
